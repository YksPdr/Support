package br.com.sobrinho.model;

public class ClientePFSobrinho extends ClienteBancoSobrinho {
	private int cpfSobrinho;

	public int getCpfSobrinho() {
		return cpfSobrinho;
	}

	public void setCpfSobrinho(int cpfSobrinho) {
		this.cpfSobrinho = cpfSobrinho;
	}
}