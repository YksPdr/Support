package br.com.sobrinho.model;

public class ClienteBancoSobrinho {
	private String nomeSobrinho;
	private String enderecoSobrinho;
	private String nomeAgenciaSobrinho;
	private String nomeGerenteSobrinho;
	
	public String getNomeSobrinho() {
		return nomeSobrinho;
	}
	public void setNomeSobrinho(String nomeSobrinho) {
		this.nomeSobrinho = nomeSobrinho;
	}
	public String getEnderecoSobrinho() {
		return enderecoSobrinho;
	}
	public void setEnderecoSobrinho(String enderecoSobrinho) {
		this.enderecoSobrinho = enderecoSobrinho;
	}
	public String getNomeAgenciaSobrinho() {
		return nomeAgenciaSobrinho;
	}
	public void setNomeAgenciaSobrinho(String nomeAgenciaSobrinho) {
		this.nomeAgenciaSobrinho = nomeAgenciaSobrinho;
	}
	public String getNomeGerenteSobrinho() {
		return nomeGerenteSobrinho;
	}
	public void setNomeGerenteSobrinho(String nomeGerenteSobrinho) {
		this.nomeGerenteSobrinho = nomeGerenteSobrinho;
	}
}