package br.com.sobrinho.model;

public class ClientePJSobrinho extends ClienteBancoSobrinho {
	private int cnpjSobrinho;

	public int getCnpjSobrinho() {
		return cnpjSobrinho;
	}

	public void setCnpjSobrinho(int cnpjSobrinho) {
		this.cnpjSobrinho = cnpjSobrinho;
	}
}