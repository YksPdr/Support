module SantanderSobrinho {
	requires java.sql;
	requires java.desktop;
}