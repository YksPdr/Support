package br.com.sobrinho.model;

public class ClienteSobrinho extends PessoaSobrinho{
	private int ValorCompraSobrinho;

	public int getValorCompraSobrinho() {
		return ValorCompraSobrinho;
	}

	public void setValorCompraSobrinho(int valorCompraSobrinho) {
		ValorCompraSobrinho = valorCompraSobrinho;
	}
}