package br.com.sobrinho.model;

public class MaterialVendaSobrinho extends MaterialSobrinho{
	private int ValorCompraSobrinho;
	private int ValorVendaSobrinho;
	
	public int getValorCompraSobrinho() {
		return ValorCompraSobrinho;
	}
	public void setValorCompraSobrinho(int valorCompraSobrinho) {
		ValorCompraSobrinho = valorCompraSobrinho;
	}
	public int getValorVendaSobrinho() {
		return ValorVendaSobrinho;
	}
	public void setValorVendaSobrinho(int valorVendaSobrinho) {
		ValorVendaSobrinho = valorVendaSobrinho;
	}
}