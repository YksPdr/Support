package br.com.sobrinho.model;

public class PessoaSobrinho {
	private String NomeSobrinho;
	private int IdadeSobrinho;
	
	public String getNomeSobrinho() {
		return NomeSobrinho;
	}
	public void setNomeSobrinho(String nomeSobrinho) {
		NomeSobrinho = nomeSobrinho;
	}
	public int getIdadeSobrinho() {
		return IdadeSobrinho;
	}
	public void setIdadeSobrinho(int idadeSobrinho) {
		IdadeSobrinho = idadeSobrinho;
	}
}