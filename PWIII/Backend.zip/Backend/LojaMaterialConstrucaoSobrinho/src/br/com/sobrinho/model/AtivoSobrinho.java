package br.com.sobrinho.model;

public class AtivoSobrinho extends MaterialSobrinho{
	private int DataAquisicaoSobrinho;

	public int getDataAquisicaoSobrinho() {
		return DataAquisicaoSobrinho;
	}

	public void setDataAquisicao(int dataAquisicaoSobrinho) {
		DataAquisicaoSobrinho = dataAquisicaoSobrinho;
	}
}