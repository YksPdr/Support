package br.com.sobrinho.model;

public class MaterialSobrinho {
	private String DescricaoSobrinho;
	private double PesoSobrinho;
	
	public String getDescricaoSobrinho() {
		return DescricaoSobrinho;
	}
	public void setDescricaoSobrinho(String descricaoSobrinho) {
		DescricaoSobrinho = descricaoSobrinho;
	}
	public double getPesoSobrinho() {
		return PesoSobrinho;
	}
	public void setPesoSobrinho(double pesoSobrinho) {
		PesoSobrinho = pesoSobrinho;
	}
}