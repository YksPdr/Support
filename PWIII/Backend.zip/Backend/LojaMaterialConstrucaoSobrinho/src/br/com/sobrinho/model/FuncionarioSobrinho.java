package br.com.sobrinho.model;

public class FuncionarioSobrinho extends PessoaSobrinho{
	private double SalarioSobrinho;

	public double getSalario() {
		return SalarioSobrinho;
	}

	public void setSalario(double salarioSobrinho) {
		SalarioSobrinho = salarioSobrinho;
	}
}