module LojaMaterialConstrucaoSobrinho {
	requires java.desktop;
}