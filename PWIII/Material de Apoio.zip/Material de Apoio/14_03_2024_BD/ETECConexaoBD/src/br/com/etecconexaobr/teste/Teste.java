package br.com.etecconexaobr.teste;

import br.com.etecconexaobr.model.Pessoa;

public class Teste {

	public static void main(String[] args) {
	
		Pessoa pessoa = new Pessoa();
		
		pessoa.setNome("Rafael");
		pessoa.setEndereco("Rua X");

	}
}
