/**
 * 
 */
/**
 * @author logonpflocal
 *
 */
module FIAPConexaoBD {
	requires java.sql;
}