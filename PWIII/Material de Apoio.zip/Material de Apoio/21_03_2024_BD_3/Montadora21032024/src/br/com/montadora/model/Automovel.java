package br.com.montadora.model;

public class Automovel {
	
	private String nomeMontadora;

	public String getNomeMontadora() {
		return nomeMontadora;
	}

	public void setNomeMontadora(String nomeMontadora) {
		this.nomeMontadora = nomeMontadora;
	}
}
