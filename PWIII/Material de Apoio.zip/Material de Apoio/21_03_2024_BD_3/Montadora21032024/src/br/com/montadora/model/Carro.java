package br.com.montadora.model;

public class Carro extends Automovel{
	
	private String modeloCarro;

	public String getModeloCarro() {
		return modeloCarro;
	}

	public void setModeloCarro(String modeloCarro) {
		this.modeloCarro = modeloCarro;
	}
}
