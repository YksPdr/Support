package br.com.fabricaroupa.teste;

import java.sql.Connection;

import br.com.fabricaroupa.conexao.Conexao;
import br.com.fabricaroupa.dao.CalcaDAO;
import br.com.fabricaroupa.model.Calca;

public class ProgramaModificarCalca {
	public static void main(String[] args) {
	
		Connection con = Conexao.abrirConexao();
	
	CalcaDAO calcadao = new CalcaDAO(con);
	Calca calca = new Calca();
	
	calca.setTipoTecido("Jeans");
	calca.setTipo("Festa");
	
	calcadao.alterarTipoTecido(calca);
	Conexao.fecharConexao(con);
	}
}
