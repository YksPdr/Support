package br.com.fabricaroupa.model;

public class Calca extends Roupa{
	
	private String tipo;

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
}
