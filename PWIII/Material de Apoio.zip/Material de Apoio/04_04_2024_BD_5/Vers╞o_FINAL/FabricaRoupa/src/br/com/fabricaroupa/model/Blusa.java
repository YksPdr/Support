package br.com.fabricaroupa.model;

public class Blusa extends Roupa{
	
	private String touca;

	public String getTouca() {
		return touca;
	}

	public void setTouca(String touca) {
		this.touca = touca;
	}
}
