package br.com.fabricaroupa.model;

public class Roupa {

	private double peso;
	private String TipoTecido;
	public double getPeso() {
		return peso;
	}
	public void setPeso(double peso) {
		this.peso = peso;
	}
	public String getTipoTecido() {
		return TipoTecido;
	}
	public void setTipoTecido(String tipoTecido) {
		TipoTecido = tipoTecido;
	}
	
	
}
